-- Set `withhold-solutions: true` in a homework's front matter while the
-- assignment is still out. Solution blocks are then dropped from this page
-- rather than rendered collapsed, so the served page carries no answers.
-- The starter block is kept in that case: it is what the student works from.
-- Remove the line once the assignment has come due.
local withhold_solutions = false

function Meta(meta)
  withhold_solutions = meta['withhold-solutions'] == true
end

function Div(div)
  -- A starter is the code the student's answer box opens with in the handout, put
  -- there by bin/make-handout.py. On this page the solution is shown instead, so
  -- the starter would just be the same code twice.
  if div.classes:includes("callout-starter") then
    if withhold_solutions then
      return nil
    end
    return {}
  end
  if div.classes:includes("callout-exercise") then
    local title = ""
    if div.content[1] ~= nil and div.content[1].t == "Header" then
      title = div.content[1]
      div.content:remove(1)
    end
    return quarto.Callout({
      type = "exercise",
      content = div,
      title = title,
    })
  end
  if div.classes:includes("callout-solution") then
    if withhold_solutions then
      return {}
    end
    local title = "Solution"
    if div.content[1] ~= nil and div.content[1].t == "Header" then
      title = div.content[1]
      div.content:remove(1)
    end
    return quarto.Callout({
      type = "solution",
      content = div,
      title = title,
      collapse = true
    })
  end
end

-- Two passes, deliberately. Pandoc walks blocks before Meta, so a single-pass
-- filter would consult withhold_solutions while it was still false and render
-- the solutions anyway. Reading Meta in its own earlier pass is what makes the
-- flag take effect.
return {
  { Meta = Meta },
  { Div = Div },
}
