-- Warn during Quarto render when an answer was typed below its answer block.
-- The generated handout ships with the exact pristine source used for comparison.

local function read_file(filename)
  local file = io.open(filename, "r")
  if not file then return nil end
  local contents = file:read("*a")
  file:close()
  return contents
end

local function lines(text)
  local result = {}
  text = text:gsub("\r\n", "\n")
  for line in (text .. "\n"):gmatch("(.-)\n") do
    table.insert(result, line)
  end
  return result
end

local function trim(text)
  return text:match("^%s*(.-)%s*$")
end

local function is_placeholder(line)
  local value = trim(line):lower()
  value = value:gsub("^%*", ""):gsub("%*$", "")
  value = value:gsub("^%(", ""):gsub("%)$", "")
  return trim(value) == "your answer here"
end

local function dirname(filename)
  return filename:match("^(.*[/\\])") or ""
end

function Meta(meta)
  local baseline_value = meta["tlda-answer-baseline"]
  local input = quarto and quarto.doc and quarto.doc.input_file
  if not baseline_value or not input then return nil end

  local baseline_name = pandoc.utils.stringify(baseline_value)
  local source = read_file(input)
  local baseline = read_file(dirname(input) .. baseline_name)
  if not source or not baseline then
    io.stderr:write("WARNING: answer-placement check could not read its pristine handout baseline.\n")
    return nil
  end

  local template_lines = {}
  for _, line in ipairs(lines(baseline)) do
    local value = trim(line)
    if value ~= "" then template_lines[value] = true end
  end

  local source_lines = lines(source)
  local i = 1
  while i <= #source_lines do
    local answer_id = source_lines[i]:match("^:::+%s*%{[^}]*#(ans[%w_-]+)[^}]*%}")
    if not answer_id then
      i = i + 1
    else
      local j = i + 1
      local answered = false
      while j <= #source_lines and not source_lines[j]:match("^:::+%s*$") do
        if trim(source_lines[j]) ~= "" and not is_placeholder(source_lines[j]) then
          answered = true
        end
        j = j + 1
      end

      local k = j + 1
      while k <= #source_lines
          and not source_lines[k]:match("^:::+")
          and not source_lines[k]:match("^#{1,6}%s") do
        local value = trim(source_lines[k])
        if not answered and value ~= "" and not template_lines[value] then
          local excerpt = value:sub(1, 60)
          io.stderr:write(string.format(
            'WARNING: line %d: "%s" is outside answer block #%s and will not be marked. Move it between the ::: lines.\n',
            k, excerpt, answer_id
          ))
          break
        end
        k = k + 1
      end
      i = j + 1
    end
  end
  return nil
end
