with_seed = function(x, seed=default.seed) {
    had_seed = exists(".Random.seed", envir=.GlobalEnv, inherits=FALSE)
    if(had_seed) {
        old_seed = get(".Random.seed", envir=.GlobalEnv, inherits=FALSE)
    }
    on.exit({
        if(had_seed) {
            assign(".Random.seed", old_seed, envir=.GlobalEnv)
        } else if(exists(".Random.seed", envir=.GlobalEnv, inherits=FALSE)) {
            rm(".Random.seed", envir=.GlobalEnv)
        }
    }, add=TRUE)
    set.seed(seed)
    force(x)
}

mean_sd = function(x, mult = 1) { mean_se(x, mult = mult*sqrt(length(stats::na.omit(x)))) }

summary.lookup = function(column.name, summaries, default=NA) {  
  function(w,x) { 
    out = left_join(data.frame(w=w,x=x),                              
                    summaries[, c('w','x',column.name)],              
                    by=c('w','x')) |>                                 
      pull(column.name)                                               
    out[is.na(out)] = default                                         
    out
  }
}

coarsen = function(x, group, seed=0) {
  ({
    x.coarsened = rep(NA, length(x))
    for(gg in unique(group)) {
        x.coarsened[group==gg] = runif(sum(group==gg), min(x[group==gg]), max(x[group==gg]))
    }
    x.coarsened 
  }) |> with_seed(seed)
} 

binary.search = function(f, target, limits, steps = 50) {
    for(i in 1:steps) {
        middle = mean(limits)
        if(f(middle) < target) limits[1] = middle else limits[2] = middle
    }
    limits[2]
}

width = function(draws, center = mean(draws), alpha = .05) {
    coverage = function(w) {
        mean(center - w / 2 <= draws & draws <= center + w / 2)
    }
    binary.search(coverage, 1 - alpha,
                  c(0, 2 * max(abs(draws - center))))
}

# Continuous CDFs only; discrete distributions use the integer-support wrappers below.
width_cdf = function(cdf, center, limits, alpha=.05) {
  coverage = function(w) {
    cdf(center + w/2) - cdf(center - w/2)
  }
  binary.search(coverage, 1-alpha, limits)
}

width_binom = function(theta, n, alpha=.05) {
  if(theta == 0 || theta == 1) { return(0) }
  coverage = function(w) {
    pbinom(floor(n*(theta+w/2)),   n, theta) -
    pbinom(ceiling(n*(theta-w/2))-1, n, theta)
  }
  binary.search(coverage, 1-alpha, c(0, 2*max(theta, 1-theta)))
}

width_hyper = function(theta, n, m, alpha=.05) {
  if(theta == 0 || theta == 1) { return(0) }
  coverage = function(w) {
    phyper(floor(n*(theta+w/2)),   m*theta, m*(1-theta), n) -
    phyper(ceiling(n*(theta-w/2))-1, m*theta, m*(1-theta), n)
  }
  binary.search(coverage, 1-alpha, c(0, 2*max(theta, 1-theta)))
}


default.dot.size = 2
default.highlight.colors = c(polla, pollb, pollc, polld)
default_height = function(samples) { dnorm(0, mean=0, sd=sd(samples)) }

# fussy code to make sure the heights of the highlighted 
# dots don't change when the total number of dots changes
annotation_dot_heights = function(dots, highlight.dots, height, seed=default.seed) {
    heights = ({ 
        highlight.dot.heights = sample(1:highlight.dots)/(highlight.dots + 1)
        unhighlighted.dot.heights = setdiff(sample(1:dots), 1:highlight.dots)/(dots + 1)
        height*c(highlight.dot.heights[1:min(dots,highlight.dots)], 
                 unhighlighted.dot.heights) 
        }) |> with_seed(seed)
    heights
}


with_annotations = function(samples,
                            estimand = NA,
                            shade.center = mean(samples),
                            shade.width = NA, shade.color='green', shade.alpha=.15,
                            dots=100, interval.width=NA, 
                                      dot.size = default.dot.size,
                                      highlight.dots=3, 
                                      highlighted.dot.alpha=1, 
                                      unhighlighted.dot.alpha=.15,
                                      height=default_height(samples), vline.alpha=.8, 
                            seed=default.seed) { 
    highlight.colors = if(highlight.dots) default.highlight.colors[1:min(dots,highlight.dots)] else c()
    summary.data = data.frame(
        mus=mean(samples),
        mu=shade.center, 
        w66 = width(samples, alpha=1/3),
        w95 = width(samples, alpha=.05),
        shade.width=shade.width,
        estimand=estimand)

    estimand.geom = if(is.na(summary.data$estimand)) geom_blank() else 
        geom_vline(aes(xintercept=estimand), 
                   color='green', linewidth=3, alpha=.8, 
                   data=summary.data)
    shade.geom = if(is.na(summary.data$shade.width)) geom_blank() else 
        geom_rect(aes(xmin=mu-shade.width/2, 
                      xmax=mu+shade.width/2, ymin=0, ymax=Inf), 
                  fill=shade.color, alpha=shade.alpha, 
                  data=summary.data)
    dot.geom = if(dots == 0) geom_blank() else {
        heights = annotation_dot_heights(dots, highlight.dots, height, seed)
        dot.data = data.frame(
            x=samples[1:dots], 
            y=heights, 
            w=interval.width,
            color=c(highlight.colors, 
                    rep('purple', dots-length(highlight.colors))),
            alpha=c(rep(highlighted.dot.alpha,   length(highlight.colors)), 
                    rep(unhighlighted.dot.alpha, dots-length(highlight.colors))))       
        if(any(is.na(interval.width)))
                geom_point(aes(y=y, x=x, color=I(color), alpha=I(alpha)), 
                           size=dot.size, data=dot.data)
        else 
            geom_pointrange(aes(y=y, x=x, xmin=x-w/2, xmax=x+w/2, color=I(color), alpha=I(alpha)), 
                            size=dot.size/4, linewidth=dot.size/4, data=dot.data)
    }
    
    vlines = if(is.na(vline.alpha)) geom_blank() else { 
        list(geom_vline(aes(xintercept=mus), color="blue", data=summary.data, alpha=vline.alpha),
             geom_vline(aes(xintercept=mus-w66/2), color="blue", linetype='dashed', data=summary.data, alpha=vline.alpha),
             geom_vline(aes(xintercept=mus+w66/2), color="blue", linetype='dashed', data=summary.data, alpha=vline.alpha), 
             geom_vline(aes(xintercept=mus-w95/2), color="blue", linetype='dotted', data=summary.data, alpha=vline.alpha),
             geom_vline(aes(xintercept=mus+w95/2), color="blue", linetype='dotted', data=summary.data, alpha=vline.alpha))
    }
    geoms = list(estimand.geom, shade.geom, dot.geom, vlines)
    geoms
}
